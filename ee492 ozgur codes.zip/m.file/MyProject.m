function varargout = MyProject(varargin)
% MYPROJECT MATLAB code for MyProject.fig
%      MYPROJECT, by itself, creates a new MYPROJECT or raises the existing
%      singleton*.
%
%      H = MYPROJECT returns the handle to a new MYPROJECT or the handle to
%      the existing singleton*.
%
%      MYPROJECT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MYPROJECT.M with the given input arguments.
%
%      MYPROJECT('Property','Value',...) creates a new MYPROJECT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MyProject_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MyProject_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MyProject

% Last Modified by GUIDE v2.5 23-Mar-2019 16:47:59

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MyProject_OpeningFcn, ...
                   'gui_OutputFcn',  @MyProject_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
% --- Executes just before MyProject is made visible.
function MyProject_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MyProject (see VARARGIN)

% Choose default command line output for MyProject
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
% UIWAIT makes MyProject wait for user response (see UIRESUME)
% uiwait(handles.figure1);
% --- Outputs from this function are returned to the command line.
function varargout = MyProject_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% --- Executes on button press in ImportImage.
function ImportImage_Callback(hObject, eventdata, handles)
% hObject    handle to ImportImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[filename, pathname] = uigetfile({'*.png';'*.tif';'*.jpg';'*.jpeg'},'Select File');
setappdata(0,'filename',filename);
img = imread([pathname filename]);
axes(handles.axes1); 
imshow(img);
setappdata(0,'img',img);
setappdata(0,'filename',img);

% --- Executes on button press in Gray.
function Gray_Callback(hObject, eventdata, handles)
% hObject    handle to Gray (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
a=getappdata(0,'img');
a_gray=rgb2gray(a);
axes(handles.axes1); 
imshow(a_gray);
setappdata(0,'img',a_gray);

% --- Executes on button press in BlackWhite.
function BlackWhite_Callback(hObject, eventdata, handles)
% hObject    handle to BlackWhite (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img=getappdata(0,'img');
img_bw=im2bw(img,.57);
setappdata(0,'filename',img_bw);
axes(handles.axes3);
imshow(img_bw);
    
% --- Executes on button press in Red.
function Red_Callback(hObject, eventdata, handles)
% hObject    handle to Red (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img=getappdata(0,'img');
red=img;
red(:,:,2:3)=0;
setappdata(0,'filename',red);
setappdata(0,'ImRotation',red);
axes(handles.axes3);
imshow(red);

% --- Executes on button press in Reset.
function Reset_Callback(hObject, eventdata, handles)
% hObject    handle to Reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cla(handles.axes3);

% --- Executes on button press in Exit.
function Exit_Callback(hObject, eventdata, handles)
% hObject    handle to Exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
msgbox('Thanks for Using Image Processing Tool')
pause(3)
close();

% --- Executes on button press in Histogram.
function Histogram_Callback(hObject, eventdata, handles)
% hObject    handle to Histogram (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
a=getappdata(0,'img');
axes(handles.axes3);
imhist(a);

% --- Executes on button press in Complement.
function Complement_Callback(hObject, eventdata, handles)
% hObject    handle to Complement (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img=getappdata(0,'img');
IM=imcomplement(img);
axes(handles.axes3);
imshow(IM);


% --- Executes on button press in RAClockwise.
function RAClockwise_Callback(hObject, eventdata, handles)
% hObject    handle to RAClockwise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ImRotation=getappdata(0,'img');
ImRotateAntiClockwise=imrotate(ImRotation,90);
setappdata(0,'ImRotation',ImRotateAntiClockwise);
axes(handles.axes3)
imshow(ImRotateAntiClockwise)

% --- Executes on button press in RClockwise.
function RClockwise_Callback(hObject, eventdata, handles)
% hObject    handle to RClockwise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ImRotation=getappdata(0,'img');
ImRotateClockwise=imrotate(ImRotation,-90);
setappdata(0,'ImRotation',ImRotateClockwise);
axes(handles.axes3)
imshow(ImRotateClockwise)

% --- Executes on button press in FHorizontal.
function FHorizontal_Callback(hObject, eventdata, handles)
% hObject    handle to FHorizontal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
I=getappdata(0,'img');
I2=flipdim(I,2);
axes(handles.axes3)
imshow(I2);

% --- Executes on button press in FVertical.
function FVertical_Callback(hObject, eventdata, handles)
% hObject    handle to FVertical (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
I=getappdata(0,'img');
I3=flipdim(I,1);
axes(handles.axes3)
imshow(I3);

% --- Executes on button press in FHorizontalVertical.
function FHorizontalVertical_Callback(hObject, eventdata, handles)
% hObject    handle to FHorizontalVertical (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
I=getappdata(0,'img');
I2=flipdim(I,2);
I3=flipdim(I,1);
I4=flipdim(I3,2);
axes(handles.axes3)
imshow(I4);




% --- Executes on button press in EDCanny.
function EDCanny_Callback(hObject, eventdata, handles)
% hObject    handle to EDCanny (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
E=getappdata(0,'img');
BW=edge(E,'canny');
axes(handles.axes3);
imshow(BW);


% --- Executes on button press in EDSobel.
function EDSobel_Callback(hObject, eventdata, handles)
% hObject    handle to EDSobel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
E=getappdata(0,'img');
BW=edge(E,'sobel');
axes(handles.axes3);
imshow(BW);

% --- Executes on button press in TotalVariation.
function TotalVariation_Callback(hObject, eventdata, handles)
% hObject    handle to TotalVariation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
D1=double(getappdata(0,'imgnoisy'));

J=tv(D1,300);

axes(handles.axes3);
imagesc(J);
colormap(gray)




function J=tv(D1,iter,dt,ep,lam,I0,C)

%% Private function: tv (by Guy Gilboa).

%% Total Variation denoising.

%% Example: J=tv(I,iter,dt,ep,lam,I0)

%% Input: I    - image (double array gray level 1-256),

%%        iter - num of iterations,

%%        dt   - time step [0.2],

%%        ep   - epsilon (of gradient regularization) [1],

%%        lam  - fidelity term lambda [0],

%%        I0   - input (noisy) image [I0=I]

%%       (default values are in [])

%% Output: evolved image

if ~exist('ep')

   ep=1;

end

if ~exist('dt')

   dt=ep/5;  % dt below the CFL bound

end

if ~exist('lam')

   lam=0;

end

if ~exist('I0')

       I0=D1;

end

if ~exist('C')

       C=0;

end

[ny,nx]=size(D1); ep2=ep^2;

for i=1:iter,  %% do iterations

   % estimate derivatives

   I_x = (D1(:,[2:nx nx])-D1(:,[1 1:nx-1]))/2;

       I_y = (D1([2:ny ny],:)-D1([1 1:ny-1],:))/2;

       I_xx = D1(:,[2:nx nx])+D1(:,[1 1:nx-1])-2*D1;

       I_yy = D1([2:ny ny],:)+D1([1 1:ny-1],:)-2*D1;

       Dp = D1([2:ny ny],[2:nx nx])+D1([1 1:ny-1],[1 1:nx-1]);

       Dm = D1([1 1:ny-1],[2:nx nx])+D1([2:ny ny],[1 1:nx-1]);

       I_xy = (Dp-Dm)/4;

   % compute flow

   Num = I_xx.*(ep2+I_y.^2)-2*I_x.*I_y.*I_xy+I_yy.*(ep2+I_x.^2);

   Den = (ep2+I_x.^2+I_y.^2).^(3/2);

   I_t = Num./Den + lam.*(I0-D1+C);

   D1=D1+dt*I_t;  %% evolve image by dt

end % for i

%% return image

%J=I*Imean/mean(mean(I)); % normalize to original mean

J=D1;

% --- Executes on button press in CollaborativeFiltering.
function CollaborativeFiltering_Callback(hObject, eventdata, handles)
% hObject    handle to CollaborativeFiltering (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
addpath('Senior Project\matlabCodeOfDenoising\BM3D\BM3D');
y=im2double(getappdata(0,'img'));
sigma=25;
z=double(getappdata(0,'imgnoisy'));
[NA,y_est]=BM3D(1,z,sigma);
axes(handles.axes3);
imshow(y_est);




% --- Executes on button press in CurveletTransform.
function CurveletTransform_Callback(hObject, eventdata, handles)
% hObject    handle to CurveletTransform (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
addpath('Senior Project\matlabCodeOfDenoising\CurveLab-2.1.3\fdct_wrapping_matlab')

disp(' ');
disp('fdct_wrapping_demo_denoise.m -- Image denoising using Curvelets');
disp(' ');
disp('Denoising is achieved by hard-thresholding of the curvelet coefficients.');
disp('We select the thresholding at 3*sigma_jl for all but the finest scale');
disp('where it is set at 4*sigmajl; here sigma_jl is the noise level of a');
disp('coefficient at scale j and angle l (equal to the noise level times');
disp('the l2 norm of the corresponding curvelet). There are many ways to compute');
disp('the sigma_jl''s, e.g. by computing the norm of each individual curvelet,');
disp('and in this demo, we do an exact computation by applying a forward curvelet');
disp('transform on an image containing a delta function at its center.');
disp(' ');


n = size(getappdata(0,'img'),1);
sigma = 20;        
noisy_img=double(getappdata(0,'imgnoisy'));

disp('Compute all thresholds');
F = ones(n);
X = fftshift(ifft2(F)) * sqrt(prod(size(F)));
tic, C = fdct_wrapping(X,0,2); toc;

% Compute norm of curvelets (exact)
E = cell(size(C));
for s=1:length(C)
  E{s} = cell(size(C{s}));
  for w=1:length(C{s})
    A = C{s}{w};
    E{s}{w} = sqrt(sum(sum(A.*conj(A))) / prod(size(A)));
  end
end

% Take curvelet transform
disp(' ');
disp('Take curvelet transform: fdct_wrapping');
tic; C = fdct_wrapping(noisy_img,1,2); toc;

% Apply thresholding
Ct = C;
for s = 2:length(C)
  thresh = 3*sigma + sigma*(s == length(C));
  for w = 1:length(C{s})
    Ct{s}{w} = C{s}{w}.* (abs(C{s}{w}) > thresh*E{s}{w});
  end
end

% Take inverse curvelet transform 
disp(' ');
disp('Take inverse transform of thresholded data: ifdct_wrapping');
tic; restored_img = real(ifdct_wrapping(Ct,1)); toc;

axes(handles.axes3);
imagesc(restored_img); colormap gray; axis('image')

% --- Executes on button press in KernelRegression.
function KernelRegression_Callback(hObject, eventdata, handles)
% hObject    handle to KernelRegression (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
addpath('Senior Project\matlabCodeOfDenoising\kernel\KernelRegressionBasedImageProcessingToolBox_ver1-2beta\KernelRegression');
addpath('Senior Project\matlabCodeOfDenoising\kernel\KernelRegressionBasedImageProcessingToolBox_ver1-2beta\SupportFunctions');
% A denoising example by iterative steering kernel regression
%
% written by hiro, June 17 2007

% load image
img = double(getappdata(0,'img'));
[N,M] = size(img);


y = double(getappdata(0,'imgnoisy'));

% pilot estimation by second order classic kernel regression
h = 0.5;    % the global smoothing parameter
r = 1;      % the upscaling factor
ksize = 5;  % the kernel size
[zc, zx1c, zx2c] = ckr2_regular(y, h, r, ksize);

% iteartive steering kernel regression (second order)
IT = 15;     % the total number of iterations
wsize = 11;  % the size of the local orientation analysis window
lambda = 1;  % the regularization for the elongation parameter
alpha = 0.5; % the structure sensitive parameter
h = 2.4;     % the global smoothing parameter
ksize = 21;  % the kernel size
z = zeros(N, M, IT+1);
zx1 = zeros(N, M, IT+1);
zx2 = zeros(N, M, IT+1);
rmse = zeros(IT+1, 1);
z(:,:,1) = y;
zx1(:,:,1) = zx1c;
zx2(:,:,1) = zx2c;
error = img - y;
rmse(1) = sqrt(mymse(error(:)));

for i = 2 : IT+1
    % compute steering matrix
    C = steering(zx1(:,:,i-1), zx2(:,:,i-1), ones(size(img)), wsize, lambda, alpha);
    % steering kernel regression
    [zs, zx1s, zx2s] = skr2_regular(z(:,:,i-1), h, C, r, ksize);
    z(:,:,i) = zs;
    zx1(:,:,i) = zx1s;
    zx2(:,:,i) = zx2s;
    % root mean square error
    error = img - zs;
    rmse(i) = sqrt(mymse(error(:)));
    rmse(i)
    %figure(99); imagesc(zs); colormap(gray); axis image; pause(1);
end

% display images
axes(handles.axes3);
imagesc(z(:,:,13)); colormap(gray); axis image
fprintf(['ISKR, 12 iterations, RMSE=', num2str(rmse(13)),'\n']);


% --- Executes on button press in DCTDictionary.
function DCTDictionary_Callback(hObject, eventdata, handles)
% hObject    handle to DCTDictionary (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
addpath('Senior Project\matlabCodeOfDenoising\K-SVD\KSVD_Matlab_ToolBox')
bb=8; % block size
RR=4; % redundancy factor
K=RR*bb^2; % number of atoms in the dictionary

sigma = 25; 

IMin0 = (getappdata(0,'img'));
IMin0=im2double(IMin0);
if (length(size(IMin0))>2)
    IMin0 = rgb2gray(IMin0);
end
if (max(IMin0(:))<2)
    IMin0 = IMin0*255;
end
IMin = double(getappdata(0,'imgnoisy'));
PSNRIn = 20*log10(255/sqrt(mean((IMin(:)-IMin0(:)).^2)));
[IoutDCT,output] = denoiseImageDCT(IMin, sigma, K);

PSNROut = 20*log10(255/sqrt(mean((IoutDCT(:)-IMin0(:)).^2)));

axes(handles.axes3);
imshow(IoutDCT,[]); fprintf(strcat(['Clean Image by DCT dictionary, ',num2str(PSNROut),' dB\n']));
figure;
I = displayDictionaryElementsAsImage(output.D, floor(sqrt(K)), floor(size(output.D,2)/floor(sqrt(K))),bb,bb,0);
title('The DCT dictionary');

% --- Executes on button press in GlobalDictionary.
function GlobalDictionary_Callback(hObject, eventdata, handles)
% hObject    handle to GlobalDictionary (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA
addpath('Senior Project\matlabCodeOfDenoising\K-SVD\KSVD_Matlab_ToolBox')
bb=8; % block size
RR=4; % redundancy factor
K=RR*bb^2; % number of atoms in the dictionary

sigma = 25; 

IMin0 = (getappdata(0,'img'));
IMin0=im2double(IMin0);
if (length(size(IMin0))>2)
    IMin0 = rgb2gray(IMin0);
end
if (max(IMin0(:))<2)
    IMin0 = IMin0*255;
end
IMin = double(getappdata(0,'imgnoisy'));
PSNRIn = 20*log10(255/sqrt(mean((IMin(:)-IMin0(:)).^2)));
[IoutGlobal,output] = denoiseImageGlobal(IMin, sigma,K);

PSNROut = 20*log10(255/sqrt(mean((IoutGlobal(:)-IMin0(:)).^2)));
axes(handles.axes3);
imshow(IoutGlobal,[]);fprintf(strcat(['Clean Image by Global Trained dictionary, ',num2str(PSNROut),' dB\n']));
figure;
I = displayDictionaryElementsAsImage(output.D, floor(sqrt(K)), floor(size(output.D,2)/floor(sqrt(K))),bb,bb);
title('The dictionary trained on patches from natural images');

% --- Executes on button press in KSVDDictionary.
function KSVDDictionary_Callback(hObject, eventdata, handles)
% hObject    handle to KSVDDictionary (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
addpath('Senior Project\matlabCodeOfDenoising\K-SVD\KSVD_Matlab_ToolBox')
bb=8; % block size
RR=4; % redundancy factor
K=RR*bb^2; % number of atoms in the dictionary

sigma = 25; 

IMin0 = (getappdata(0,'img'));
IMin0=im2double(IMin0);
if (length(size(IMin0))>2)
    IMin0 = rgb2gray(IMin0);
end
if (max(IMin0(:))<2)
    IMin0 = IMin0*255;
end
IMin = double(getappdata(0,'imgnoisy'));
PSNRIn = 20*log10(255/sqrt(mean((IMin(:)-IMin0(:)).^2)));

[IoutAdaptive,output] = denoiseImageKSVD(IMin, sigma,K);

PSNROut = 20*log10(255/sqrt(mean((IoutAdaptive(:)-IMin0(:)).^2)));
axes(handles.axes3);
imshow(IoutAdaptive,[]);fprintf(strcat(['Clean Image by Adaptive dictionary, ',num2str(PSNROut),' dB\n']));
figure;
I = displayDictionaryElementsAsImage(output.D, floor(sqrt(K)), floor(size(output.D,2)/floor(sqrt(K))),bb,bb);
title('The dictionary trained on patches from the noisy image');


% --- Executes on button press in GaussianNoise.
function GaussianNoise_Callback(hObject, eventdata, handles)
% hObject    handle to GaussianNoise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of GaussianNoise
   if get(hObject,'Value')==1
    img=getappdata(0,'img');
    prompt = {'Enter Noise Value'};
    title = 'Input';
    dims = [1 35];
    answer = inputdlg(prompt,title,dims);
    user_val = str2num(answer{1});
    N = imnoise(img,'gaussian', user_val);
    axes(handles.axes2);
    imshow(N);
    setappdata(0,'imgnoisy',N);
    else
       cla(handles.axes2);
   end
   
   % --- Executes on button press in GaussianKernel.
function GaussianKernel_Callback(hObject, eventdata, handles)
% hObject    handle to GaussianKernel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
I=double(getappdata(0,'imgnoisy'));
 %Design the Gaussian Kernel
%Standard Deviation
sigma = 1.76;
%Window size
sz = 4;
[x,y]=meshgrid(-sz:sz,-sz:sz);

M = size(x,1)-1;
N = size(y,1)-1;
Exp_comp = -(x.^2+y.^2)/(2*sigma*sigma);
Kernel= exp(Exp_comp)/(2*pi*sigma*sigma);

 %Initialize
Output=zeros(size(I));
%Pad the vector with zeros
I = padarray(I,[sz sz]);

%Convolution
for i = 1:size(I,1)-M
    for j =1:size(I,2)-N
        Temp = I(i:i+M,j:j+M).*Kernel;
        Output(i,j)=sum(Temp(:));
    end
end
Output = uint8(Output);
axes(handles.axes3);
imshow(Output);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

  
   function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
