% MainTest - denoise an image
% this is a test file demonstrating how to denoise an image, 
% using learned dictionaries. The methods implemented here are the same
% one as described in "Image Denoising Via Sparse and Redundant
% representations over Learned Dictionaries", (appeared in the 
% IEEE Trans. on Image Processing, Vol. 15, no. 12, December 2006).

clear; close all;clc;

rand('state',0);
randn('state',0);

% Set initial input value
Param.k=256; % number of atoms in the dictionary
Param.noise = 25; % noise level
Param.method = 'SimCO';
ImageName = 'lena.png'; %image source
OriginalImage=im2double(imread(ImageName)); 
OriginalImage = OriginalImage*255;
NoisedImage=OriginalImage+Param.noise*randn(size(OriginalImage));

%time_start = clock;
% Denoise the corrupted image using learned dicitionary from corrupted image 
[DenoisedImage, timecost] = denoiseImage(NoisedImage, Param);
%time_end = clock;
%timecost = etime(time_end,time_start);

NoisedPSNR = 20*log10(255/sqrt(mean((NoisedImage(:)-OriginalImage(:)).^2)));
DenoisedPSNR = 20*log10(255/sqrt(mean((DenoisedImage(:)-OriginalImage(:)).^2)));

if strcmp(Param.method, 'KSVD')
    save RealData_KSVD DenoisedPSNR DenoisedImage timecost;
end

if strcmp(Param.method, 'SimCO')
    save RealData_SimCO DenoisedPSNR DenoisedImage timecost;
end

if strcmp(Param.method, 'PSimCO')
    save RealData_PSimCO DenoisedPSNR DenoisedImage timecost;
end

if strcmp(Param.method, 'MOD')
    save RealData_MOD DenoisedPSNR DenoisedImage timecost;
end



% Display the results
figure;
subplot(1,3,1); imshow(OriginalImage,[]); title('Original clean image');
subplot(1,3,2); imshow(NoisedImage,[]); title(strcat(['Noisy image, ',num2str(NoisedPSNR),'dB']));
subplot(1,3,3); imshow(DenoisedImage,[]); title(strcat(['Denoised Image by trained dictionary, ',num2str(DenoisedPSNR),'dB']));
