Real data experiment for Primitive SimCO, Regularized SimCO, MOD and K-SVD (including both dictionary update, sparse coding and denoising stages) 

The 'RealdataDemo' folder includes all files for experiments testing the performance of image denoising based on dictionary which learned by SimCO, Regularized SimCO, MOD and K-SVD. They are used to produce the simulation results in Figure 3 of the SimCO paper (http://arxiv.org/abs/1109.5302).

==================================================

SimCO is a novel framework that generalizes two methods: KSVD and MOD. It can update an arbitrary set of codewords and the corresponding sparse coefficients simultaneously:

References:
W. Dai, T. Xu, and W. Wang, "Simultaneous Codeword Optimisation (SimCO) for Dictionary Update and Learning", IEEE Transactions on Signal Processing, vol. 60, no. 12, pp. 6340-6353, 2012.
Full text is available at http://arxiv.org/abs/1109.5302

If you find the software package useful, please cite the above reference in your work.

MOD and K-SVD are algorithms finding a dictionary for linear representation of signals. Given a set of signals, it searches for the best dictionary that can sparsely represent each signal:

The detail can be found in: "The K-SVD: An Algorithm for Designing of Overcomplete Dictionaries for Sparse Representation", written by M. Aharon, M. Elad, and A. M. Bruckstein and appeared in the IEEE Trans. On Signal Processing, Vol. 54, no. 11, pp. 4311-4322, November 2006

"Method of Optimal Directions for Frame Design", written by K. Engan in Proc. ICASSP 1999, pp. 2443-2446, March 1999

==================================================

The core files for SimCO include the following three functions:


'DictUpdate03.m' implements the SimCO dictionary update stage. Using this function, the dictionary matrix can be produced from the training data. This function implements the second stage (i.e. dictionary update stage) of Algorithm 1, which iteratively calls "DictLineSearch03.m" and "fg_tilde_eval01.m", i.e. the implementation of Algorithm 2 in the SimCO paper (http://arxiv.org/abs/1109.5302).

'DictLineSearch03.m' updates the atoms of the dictionary in each iteration. This function implements Algorithm 2 in Section IV.A of the SimCO paper (http://arxiv.org/abs/1109.5302).

'fg_tilde_eval01.m' computes the gradient descent direction to be called by 'DictLineSearch03.m' in regularized SimCO version. In other words, this function computes equation (11) and (9) in Section IV.A of the SimCO paper (http://arxiv.org/abs/1109.5302).

'OMP.m' is the sparse coding algorithm to produce the coefficients from training data given the dictionary matrix. 


==================================================

The core file for K-SVD is included below for comparison purpose:

'K_DictUpdate02.m' the code for dictionary update stage in K-SVD.


==================================================

The core file for MOD is included below for comparison purpose:

'M_DictUpdate02.m' the code for dictionary update stage in MOD.


==================================================

The test files are shown below:

'Main_test.m' tests the performance of denoising an image by Primitive SimCO, Regularized SimCO, MOD or K-SVD.

'denoisingImage.m' is the image denoising program developed Michael Elad and Michal Aharon in 'Image Denoising Via Sparse and Redundant Representations Over Learned Dictionaries'.


==================================================

The folder 'ResultsPlot' includes all results data and plot file.
